
import os

logo = """
╔══════════════════════════════╗
        IZ-FLOW TERMINAL
╚══════════════════════════════╝
"""

print(logo)

print("System: IZ-Flow OS")
print("Type 'help' for commands")
print()

while True:

    cmd = input("iz-flow> ")

    if cmd == "exit":
        print("Shutting down IZ-Flow...")
        break

    elif cmd == "help":
        print("""
Commands:

run demo.iz   start program
system        show system files
clear         clear terminal
exit          close terminal
""")

    elif cmd.startswith("run"):
        try:
            file = cmd.split(" ")[1]
            print("Running:", file)
            os.system("python interpreter/izflow.py")
        except:
            print("Example: run demo.iz")

    elif cmd == "system":
        print("System modules:")
        print("- boot.iz")
        print("- core.iz")

    elif cmd == "clear":
        os.system("cls" if os.name == "nt" else "clear")

    else:
        print("Unknown command")
