# IZ-Flow Terminal Demo

Run with:

python terminal/iz_terminal_ui.py
